package nz.ac.vuw.ecs.swen225.gp20.monkey;

public class monkeytestingclass {
}
