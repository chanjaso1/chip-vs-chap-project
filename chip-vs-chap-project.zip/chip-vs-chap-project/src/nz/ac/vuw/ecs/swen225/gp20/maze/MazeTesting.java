package nz.ac.vuw.ecs.swen225.gp20.maze;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * This class is the test class that test things in Maze class.
 */
public class MazeTesting {

    @Test
    public void testPickingUpKey(){
        Game game = new Game(1);
        Player player = game.getPlayer();

        new moveDown(player).apply();
        new moveLeft(player).apply();

        assertEquals(1,player.getKeys().size());
    }


}
